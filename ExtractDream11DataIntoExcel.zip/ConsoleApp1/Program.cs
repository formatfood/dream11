﻿using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    static class Program
    {
        public static string path = @"D:\dream11\luckywinners9.xlsx";
        public static string connStr = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + path + ";Extended Properties=Excel 12.0;";
        public static List<Player> initialPlayerList = new List<Player>();
        public static string TeamA = "AUS";
        public static string TeamB = "ENG";
        public static int minTeam = 4;
        public static int minWK = 1;
        public static int minBAT = 3;
        public static int minAR = 1;
        public static int minBOWL = 3;
        public static double maxCredits = 100.00;
        public static int totalPlayer = 11;
        public static List<Team> finalTeams = new List<Team>();
        public static string requiredPlayers = "abcdefghi";
        public static int minRequiredPlayers = 5;
        public static string doubtPlayers = "";
        public static string selectedDoubtPlayers = "";
        public static int id = 1;
        public static string capPlayers = "abcdefghi";
        public static DataTable table = new DataTable();
        public static bool isPlayerSelection = true;
        public static string SheetName = "Sheet1";
        public static string[] SheetArray = "1".Split(',');
        public static List<string> allCombinations2 = new List<String>();
        public static List<string> allCombinations22 = new List<String>();
        public static int c = 0;
        public static int v = 1;

        /// <summary>
        /// main method to initialize
        /// </summary>
        /// <param name="args"></param>
        static void Main(string[] args)
        {

            if (isPlayerSelection)
            {
                foreach (var s in SheetArray)
                {
                    SheetName = "Sheet" + s;
                    table = new DataTable();
                    finalTeams = new List<Team>();
                    initialPlayerList = new List<Player>();
                    ConvertDtToObject(ReadDataFromExcel());
                    TeamCaptainSelections();
                    allCombinations22.AddRange(allCombinations2);
                    TeamPlayerSelections();
                }
            }
            else
            {
                TeamCaptainSelections();
            }
            Console.ReadLine();
        }

        /// <summary>
        /// help select the team captain and vice captain
        /// </summary>
        private static void TeamCaptainSelections()
        {
            var tcDt = CreateTableForCaptainSelections();
            var strChars = capPlayers;
            var chars = strChars.ToList();
            var allCombinations = new List<String>();
            //for (int i = 1; i <= chars.Count; i++)
            //{
            var combis = new Facet.Combinatorics.Combinations<Char>(
                chars, 2, Facet.Combinatorics.GenerateOption.WithoutRepetition);
            allCombinations.AddRange(combis.Select(c => string.Join("", c)));

            long j = 1;
            foreach (var combi in allCombinations)
            {
                Console.WriteLine(j.ToString());
                var t = initialPlayerList.Where(s => combi.ToCharArray().Contains(s.Id)).ToList();
                ValidateTeamCap(t, tcDt);
                j++;
            }
            tcDt.ToCSV(@"D:\dream11\" + TeamA + "-" + TeamB + "-" + SheetName + ".csv");
        }

        /// <summary>
        /// help to get the random number of players from the given inputs(players list from excel)
        /// with minimumn bowling and minimum batting and minimum all rounder and the wicket keeper
        /// And most importantly it will calculate the credits ex 100. And also it will select the min
        /// players from one team
        /// 
        /// output: players and his roles, team 
        /// </summary>
        private static void TeamPlayerSelections()
        {
            CreateTableForPlayerSelections();
            var strChars = string.Empty;
            foreach (var p in initialPlayerList)
            {
                strChars += p.Id;
            }

            var chars = strChars.ToList();
            var allCombinations = new List<String>();
            var combis = new Facet.Combinatorics.Combinations<Char>(
                chars, totalPlayer, Facet.Combinatorics.GenerateOption.WithoutRepetition);
            allCombinations.AddRange(combis.Select(c => string.Join("", c)));

            long j = 1;
            foreach (var combi in allCombinations)
            {
                Console.WriteLine(j.ToString());
                var t = initialPlayerList.Where(s => combi.ToCharArray().Contains(s.Id)).ToList();
                var proTeam = ValidateTeam(t);
                if (proTeam.TeamPlayers != null)
                {
                    finalTeams.Add(proTeam);
                    Console.WriteLine(j.ToString() + "-" + combi.Length + " --- " + combi);
                }
                j++;
            }
            table.ToCSV(@"D:\dream11\" + TeamA + "-" + TeamB + "-" + SheetName + ".csv");
        }

        /// <summary>
        /// 
        /// 
        /// </summary>
        /// <param name="players"></param>
        /// <param name="dt"></param>
        private static void ValidateTeamCap(IList<Player> players, DataTable dt)
        {
            if (players.Count == 2)
            {
                var wkCount = players.Where(i => i.Role.Equals("WK")).Count();
                var batCount = players.Where(i => i.Role.Equals("BAT")).Count();
                var bowlCount = players.Where(i => i.Role.Equals("BOWL")).Count();
                var arCount = players.Where(i => i.Role.Equals("AR")).Count();


                if (wkCount == 1 || batCount == 1 || bowlCount == 1 || arCount == 1)
                {
                    var com = "";
                    foreach (var p in players)
                    {
                        DataRow dr = dt.NewRow();
                        dr[0] = id;
                        dr[1] = p.PlaeryName;
                        dr[2] = p.Team;
                        dr[3] = p.Role;
                        dt.Rows.Add(dr);
                        com = com + p.Id;
                    }
                    allCombinations2.Add(com);
                    id = id + 1;
                }

            }
        }

        /// <summary>
        ///  it will validate the team based on dream 11 condition like one wicket keeper
        /// min 3 batsman max 5 and min 3 bowers max 5 min 1 all rounder and max 3</summary>
        /// <param name="players"></param>
        /// <returns></returns>
        private static Team ValidateTeam(IList<Player> players)
        {
            var T = new Team();
            if (players.Count == totalPlayer)
            {
                var sumOfCredits = players.Sum(o => o.Credits);
                if (sumOfCredits <= maxCredits)
                {
                    var TeamACount = players.Where(i => i.Team.Equals(TeamA)).Count();
                    var TeamBCount = players.Where(i => i.Team.Equals(TeamB)).Count();
                    if (TeamACount >= minTeam && TeamBCount >= minTeam)
                    {
                        var wkCount = players.Where(i => i.Role.Equals("WK")).Count();
                        if (wkCount == minWK)
                        {
                            var batCount = players.Where(i => i.Role.Equals("BAT")).Count();
                            if (batCount >= minBAT)
                            {
                                var arCount = players.Where(i => i.Role.Equals("AR")).Count();
                                if (arCount >= minAR)
                                {
                                    var bowlCount = players.Where(i => i.Role.Equals("BOWL")).Count();
                                    if (bowlCount >= minBOWL)
                                    {
                                        var reqPlayers = players.Where(i => requiredPlayers.ToCharArray().Contains(i.Id)).Count();

                                        if (minRequiredPlayers <= reqPlayers)
                                        {
                                            var selectedCapVCap = "";
                                            if (allCombinations2.Count < 3)
                                            {
                                                allCombinations2.AddRange(allCombinations22);
                                                var swap = c;
                                                c = v;
                                                v = swap;
                                            }
                                            foreach (var capVcap in allCombinations2)
                                            {
                                                var capVcCount = players.Where(i => capVcap.ToCharArray().Contains(i.Id)).Count();
                                                selectedCapVCap = capVcap;
                                                if (capVcCount == 2)
                                                {
                                                    break;
                                                }
                                            }
                                            
                                            allCombinations2.Remove(selectedCapVCap);
                                            T.TeamPlayers = players;
                                            T.TeamACount = TeamACount;
                                            T.TeamBCount = TeamBCount;
                                            T.TotalCredits = sumOfCredits;
                                            var cap = selectedCapVCap.ToCharArray();
                                            foreach (var p in T.TeamPlayers)
                                            {
                                                DataRow dr = table.NewRow();
                                                var cv = "";
                                                if (cap[c] == p.Id)
                                                {
                                                    cv = " - C";
                                                }
                                                else if (cap[v] == p.Id)
                                                {
                                                    cv = " - VC";
                                                }
                                                dr[0] = id + "-" + reqPlayers.ToString();

                                                dr[1] = p.PlaeryName + cv;
                                                dr[2] = p.Team;
                                                dr[3] = p.Role;
                                                dr[4] = TeamA + "-" + TeamACount + ":" + TeamB + "-" + TeamBCount;
                                                dr[5] = sumOfCredits.ToString();
                                                dr[6] = wkCount.ToString() + "-" + batCount.ToString() + "-" + arCount.ToString() + "-" + bowlCount.ToString();
                                                table.Rows.Add(dr);
                                            }
                                            id = id + 1;
                                            
                                        }

                                    }
                                }
                            }
                        }
                    }
                }
            }

            return T;
        }

        /// <summary>
        /// help to read players input from excel and store it in datatable
        /// </summary>
        /// <returns></returns>
        private static DataTable ReadDataFromExcel()
        {
            System.Data.OleDb.OleDbConnection MyConnection;
            System.Data.DataSet DtSet;
            System.Data.OleDb.OleDbDataAdapter MyCommand;
            MyConnection = new System.Data.OleDb.OleDbConnection(connStr);
            MyCommand = new System.Data.OleDb.OleDbDataAdapter("select * from [" + SheetName + "$]", MyConnection);
            MyCommand.TableMappings.Add("Table", "TestTable");
            DtSet = new System.Data.DataSet();
            MyCommand.Fill(DtSet);
            MyConnection.Close();
            return DtSet.Tables[0];
        }

        /// <summary>
        /// convert datatable to collection class
        /// </summary>
        /// <param name="dt"></param>
        private static void ConvertDtToObject(DataTable dt)
        {

            foreach (DataRow dr in dt.Rows)
            {

                initialPlayerList.Add(new Player
                {
                    Id = Convert.ToChar(dr["Id"]),
                    PlaeryName = Convert.ToString(dr["Player"]).Trim(),
                    Team = Convert.ToString(dr["Team"]).Trim(),
                    Role = Convert.ToString(dr["Role"]).Trim(),
                    Points = Convert.ToDouble(dr["Points"]),
                    Credits = Convert.ToDouble(dr["Credits"])
                });
            }
        }

        /// <summary>
        /// final team will be downloded using this method
        /// </summary>
        /// <param name="dtDataTable"></param>
        /// <param name="strFilePath"></param>
        public static void ToCSV(this DataTable dtDataTable, string strFilePath)
        {
            StreamWriter sw = new StreamWriter(strFilePath, false);
            //headers  
            for (int i = 0; i < dtDataTable.Columns.Count; i++)
            {
                sw.Write(dtDataTable.Columns[i]);
                if (i < dtDataTable.Columns.Count - 1)
                {
                    sw.Write(",");
                }
            }
            sw.Write(sw.NewLine);
            foreach (DataRow dr in dtDataTable.Rows)
            {
                for (int i = 0; i < dtDataTable.Columns.Count; i++)
                {
                    if (!Convert.IsDBNull(dr[i]))
                    {
                        string value = dr[i].ToString();
                        if (value.Contains(','))
                        {
                            value = String.Format("\"{0}\"", value);
                            sw.Write(value);
                        }
                        else
                        {
                            sw.Write(dr[i].ToString());
                        }
                    }
                    if (i < dtDataTable.Columns.Count - 1)
                    {
                        sw.Write(",");
                    }
                }
                sw.Write(sw.NewLine);
            }
            sw.Close();
        }

        /// <summary>
        /// Create table for player selection - just initialize the datatable
        /// </summary>
        /// <returns></returns>
        public static DataTable CreateTableForPlayerSelections()
        {
            table.Columns.Add("DreamTeam", typeof(string));
            table.Columns.Add("Player", typeof(string));
            table.Columns.Add("Team", typeof(string));
            table.Columns.Add("Role", typeof(string));
            table.Columns.Add("DreamTeam-Sep", typeof(string));
            table.Columns.Add("TotalCredits", typeof(string));
            table.Columns.Add("batbowl", typeof(string));
            return table;
        }

        /// <summary>
        /// Create table for captain vc selection - just initialize the datatable
        /// </summary>
        /// <returns></returns>
        public static DataTable CreateTableForCaptainSelections()
        {
            var table = new DataTable();
            table.Columns.Add("DreamTeamCaptain", typeof(int));
            table.Columns.Add("Player", typeof(string));
            table.Columns.Add("Team", typeof(string));
            table.Columns.Add("Role", typeof(string));
            return table;
        }
    }
}
